const images = [
    'https://via.placeholder.com/150/FF7F7F/333333?text=Amor1',
    'https://via.placeholder.com/150/FFB6C1/333333?text=Amor2',
    'https://via.placeholder.com/150/FF7F7F/333333?text=Amor1',
    'https://via.placeholder.com/150/FFB6C1/333333?text=Amor2',
    'https://via.placeholder.com/150/FADADD/333333?text=Amor3',
    'https://via.placeholder.com/150/FFC0CB/333333?text=Amor4',
    'https://via.placeholder.com/150/FADADD/333333?text=Amor3',
    'https://via.placeholder.com/150/FFC0CB/333333?text=Amor4'
];

let firstCard = null;
let secondCard = null;
let lockBoard = false;
const winSound = document.getElementById('win-sound');

function shuffle(array) {
    array.sort(() => Math.random() - 0.5);
}

function createBoard() {
    const board = document.getElementById('game-board');
    shuffle(images);

    images.forEach(src => {
        const card = document.createElement('div');
        card.classList.add('card');
        const img = document.createElement('img');
        img.src = src;
        card.appendChild(img);

        card.addEventListener('click', flipCard);
        board.appendChild(card);
    });
}

function flipCard() {
    if (lockBoard) return;
    if (this.classList.contains('flipped')) return;

    this.classList.add('flipped');

    if (!firstCard) {
        firstCard = this;
        return;
    }

    secondCard = this;
    lockBoard = true;

    checkMatch();
}

function checkMatch() {
    const isMatch = firstCard.querySelector('img').src === secondCard.querySelector('img').src;

    if (isMatch) {
        disableCards();
    } else {
        unflipCards();
    }
}

function disableCards() {
    firstCard.removeEventListener('click', flipCard);
    secondCard.removeEventListener('click', flipCard);

    resetBoard();

    if (document.querySelectorAll('.card:not(.flipped)').length === 0) {
        showWinMessage();
    }
}

function unflipCards() {
    setTimeout(() => {
        firstCard.classList.remove('flipped');
        secondCard.classList.remove('flipped');

        resetBoard();
    }, 1000);
}

function resetBoard() {
    [firstCard, secondCard, lockBoard] = [null, null, false];
}

function showWinMessage() {
    document.getElementById('message').classList.remove('hidden');
    winSound.play();
}

createBoard();
